import { combineReducers } from 'redux'
import routeReducer from './routeReducer'

const rootReducer = combineReducers({
    routeReducer
})

export default rootReducer