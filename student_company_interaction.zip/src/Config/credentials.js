const credentials = {
    ACCESS_KEY: "AKIAIBUXZEQEM7EVVYRA",
    SECRET_KEY: "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",
    REGION: "us-east-1",
    USER_POOL_ID: "us-east-1_zDagBiDiQ",
    APP_CLIENT_ID: "2mp1oqch1qpfhqu19k2j7lp8j7",
    GRAPHQL_END_POINT: "https://4ocbygn4j5aetgf2a67blmyweu.appsync-api.us-east-1.amazonaws.com/graphql",
    AUTHENCITCATION_TYPE: "API_KEY",
    API_KEY: "da2-klew67cs2zbtrebmlouhwbw52u"
}

export default credentials;